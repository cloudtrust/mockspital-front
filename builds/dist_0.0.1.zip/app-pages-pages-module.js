(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app-pages-pages-module"],{

/***/ "./src/app/pages/dashboard/dashboard.component.html":
/*!**********************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n  <nb-card>\n    <nb-card-body>This is the body of the dashboard!</nb-card-body>\n  </nb-card>\n</div>\n"

/***/ }),

/***/ "./src/app/pages/dashboard/dashboard.component.ts":
/*!********************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.component.ts ***!
  \********************************************************/
/*! exports provided: DashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var DashboardComponent = /** @class */ (function () {
    function DashboardComponent() {
    }
    DashboardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-dashboard',
            template: __webpack_require__(/*! ./dashboard.component.html */ "./src/app/pages/dashboard/dashboard.component.html"),
        })
    ], DashboardComponent);
    return DashboardComponent;
}());



/***/ }),

/***/ "./src/app/pages/dashboard/dashboard.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.module.ts ***!
  \*****************************************************/
/*! exports provided: DashboardModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardModule", function() { return DashboardModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../@theme/theme.module */ "./src/app/@theme/theme.module.ts");
/* harmony import */ var _dashboard_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dashboard.component */ "./src/app/pages/dashboard/dashboard.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var DashboardModule = /** @class */ (function () {
    function DashboardModule() {
    }
    DashboardModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__["ThemeModule"],
            ],
            declarations: [
                _dashboard_component__WEBPACK_IMPORTED_MODULE_2__["DashboardComponent"],
            ],
        })
    ], DashboardModule);
    return DashboardModule;
}());



/***/ }),

/***/ "./src/app/pages/departments-page/departments-page.component.html":
/*!************************************************************************!*\
  !*** ./src/app/pages/departments-page/departments-page.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n  <nb-card>\n     <nb-card-header>\n         Departments\n     </nb-card-header>\n     <nb-card-body>\n       <ngx-departments-table></ngx-departments-table>\n     </nb-card-body>\n  </nb-card>\n</div>\n  "

/***/ }),

/***/ "./src/app/pages/departments-page/departments-page.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/pages/departments-page/departments-page.component.ts ***!
  \**********************************************************************/
/*! exports provided: DepartmentsPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DepartmentsPageComponent", function() { return DepartmentsPageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var DepartmentsPageComponent = /** @class */ (function () {
    function DepartmentsPageComponent() {
    }
    DepartmentsPageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-departments-page',
            template: __webpack_require__(/*! ./departments-page.component.html */ "./src/app/pages/departments-page/departments-page.component.html"),
        })
    ], DepartmentsPageComponent);
    return DepartmentsPageComponent;
}());



/***/ }),

/***/ "./src/app/pages/departments-page/departments-page.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/departments-page/departments-page.module.ts ***!
  \*******************************************************************/
/*! exports provided: DepartmentsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DepartmentsPageModule", function() { return DepartmentsPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../@theme/theme.module */ "./src/app/@theme/theme.module.ts");
/* harmony import */ var _departments_page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./departments-page.component */ "./src/app/pages/departments-page/departments-page.component.ts");
/* harmony import */ var _table_table_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./table/table.component */ "./src/app/pages/departments-page/table/table.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var DepartmentsPageModule = /** @class */ (function () {
    function DepartmentsPageModule() {
    }
    DepartmentsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__["ThemeModule"],
            ],
            declarations: [
                _departments_page_component__WEBPACK_IMPORTED_MODULE_2__["DepartmentsPageComponent"],
                _table_table_component__WEBPACK_IMPORTED_MODULE_3__["DepartmentsTableComponent"],
            ],
        })
    ], DepartmentsPageModule);
    return DepartmentsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/departments-page/table/table.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/departments-page/table/table.component.ts ***!
  \*****************************************************************/
/*! exports provided: DepartmentsTableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DepartmentsTableComponent", function() { return DepartmentsTableComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core_data_business_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../@core/data/business.service */ "./src/app/@core/data/business.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DepartmentsTableComponent = /** @class */ (function () {
    function DepartmentsTableComponent(business) {
        this.business = business;
        this.settings = {
            columns: {
                id: {
                    title: 'ID',
                },
                name: {
                    title: 'Name',
                },
                hospital: {
                    title: 'Hospital ID',
                    valuePrepareFunction: function (d) {
                        return d['id'];
                    },
                },
            },
            attr: {
                class: 'table table-bordered table-striped table-hover table-sm',
            },
        };
        this.data = [];
    }
    DepartmentsTableComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.business.getDepartments().subscribe(function (d) { return _this.data = d; });
    };
    DepartmentsTableComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-departments-table',
            template: "\n    <ng2-smart-table [settings]=\"settings\" [source]=\"data\"></ng2-smart-table>\n  ",
        }),
        __metadata("design:paramtypes", [_core_data_business_service__WEBPACK_IMPORTED_MODULE_1__["BusinessService"]])
    ], DepartmentsTableComponent);
    return DepartmentsTableComponent;
}());



/***/ }),

/***/ "./src/app/pages/doctors-page/doctors-page.component.html":
/*!****************************************************************!*\
  !*** ./src/app/pages/doctors-page/doctors-page.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n    <nb-card>\n      <nb-card-header>\n          Doctors\n      </nb-card-header>\n      <nb-card-body>\n        <ngx-doctors-table></ngx-doctors-table>\n      </nb-card-body>\n    </nb-card>\n  </div>\n  "

/***/ }),

/***/ "./src/app/pages/doctors-page/doctors-page.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/doctors-page/doctors-page.component.ts ***!
  \**************************************************************/
/*! exports provided: DoctorsPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DoctorsPageComponent", function() { return DoctorsPageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var DoctorsPageComponent = /** @class */ (function () {
    function DoctorsPageComponent() {
    }
    DoctorsPageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-doctors-page',
            template: __webpack_require__(/*! ./doctors-page.component.html */ "./src/app/pages/doctors-page/doctors-page.component.html"),
        })
    ], DoctorsPageComponent);
    return DoctorsPageComponent;
}());



/***/ }),

/***/ "./src/app/pages/doctors-page/doctors-page.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/doctors-page/doctors-page.module.ts ***!
  \***********************************************************/
/*! exports provided: DoctorsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DoctorsPageModule", function() { return DoctorsPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../@theme/theme.module */ "./src/app/@theme/theme.module.ts");
/* harmony import */ var _doctors_page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./doctors-page.component */ "./src/app/pages/doctors-page/doctors-page.component.ts");
/* harmony import */ var _table_table_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./table/table.component */ "./src/app/pages/doctors-page/table/table.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var DoctorsPageModule = /** @class */ (function () {
    function DoctorsPageModule() {
    }
    DoctorsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__["ThemeModule"],
            ],
            declarations: [
                _doctors_page_component__WEBPACK_IMPORTED_MODULE_2__["DoctorsPageComponent"],
                _table_table_component__WEBPACK_IMPORTED_MODULE_3__["DoctorsTableComponent"],
            ],
        })
    ], DoctorsPageModule);
    return DoctorsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/doctors-page/table/table.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/doctors-page/table/table.component.ts ***!
  \*************************************************************/
/*! exports provided: DoctorsTableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DoctorsTableComponent", function() { return DoctorsTableComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core_data_business_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../@core/data/business.service */ "./src/app/@core/data/business.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DoctorsTableComponent = /** @class */ (function () {
    function DoctorsTableComponent(business) {
        this.business = business;
        this.settings = {
            columns: {
                id: {
                    title: 'ID',
                },
                firstName: {
                    title: 'First name',
                },
                lastName: {
                    title: 'Last name',
                },
                departments: {
                    title: 'Department ID',
                    valuePrepareFunction: function (d) {
                        return d[0]['id'];
                    },
                },
            },
            attr: {
                class: 'table table-bordered table-striped table-hover table-sm',
            },
        };
        this.data = [];
    }
    DoctorsTableComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.business.getDoctors().subscribe(function (d) { return _this.data = d; });
    };
    DoctorsTableComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-doctors-table',
            template: "\n    <ng2-smart-table [settings]=\"settings\" [source]=\"data\"></ng2-smart-table>\n  ",
        }),
        __metadata("design:paramtypes", [_core_data_business_service__WEBPACK_IMPORTED_MODULE_1__["BusinessService"]])
    ], DoctorsTableComponent);
    return DoctorsTableComponent;
}());



/***/ }),

/***/ "./src/app/pages/files-page/files-page.component.html":
/*!************************************************************!*\
  !*** ./src/app/pages/files-page/files-page.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n    <nb-card>\n      <nb-card-header>\n          Files\n      </nb-card-header>\n      <nb-card-body>\n        <ngx-files-table></ngx-files-table>\n      </nb-card-body>\n    </nb-card>\n  </div>\n  "

/***/ }),

/***/ "./src/app/pages/files-page/files-page.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages/files-page/files-page.component.ts ***!
  \**********************************************************/
/*! exports provided: FilesPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilesPageComponent", function() { return FilesPageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var FilesPageComponent = /** @class */ (function () {
    function FilesPageComponent() {
    }
    FilesPageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-files-page',
            template: __webpack_require__(/*! ./files-page.component.html */ "./src/app/pages/files-page/files-page.component.html"),
        })
    ], FilesPageComponent);
    return FilesPageComponent;
}());



/***/ }),

/***/ "./src/app/pages/files-page/files-page.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/files-page/files-page.module.ts ***!
  \*******************************************************/
/*! exports provided: FilesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilesPageModule", function() { return FilesPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../@theme/theme.module */ "./src/app/@theme/theme.module.ts");
/* harmony import */ var _files_page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./files-page.component */ "./src/app/pages/files-page/files-page.component.ts");
/* harmony import */ var _table_table_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./table/table.component */ "./src/app/pages/files-page/table/table.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var FilesPageModule = /** @class */ (function () {
    function FilesPageModule() {
    }
    FilesPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__["ThemeModule"],
            ],
            declarations: [
                _files_page_component__WEBPACK_IMPORTED_MODULE_2__["FilesPageComponent"],
                _table_table_component__WEBPACK_IMPORTED_MODULE_3__["FilesTableComponent"],
            ],
        })
    ], FilesPageModule);
    return FilesPageModule;
}());



/***/ }),

/***/ "./src/app/pages/files-page/table/table.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/files-page/table/table.component.ts ***!
  \***********************************************************/
/*! exports provided: FilesTableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilesTableComponent", function() { return FilesTableComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core_data_business_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../@core/data/business.service */ "./src/app/@core/data/business.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var FilesTableComponent = /** @class */ (function () {
    function FilesTableComponent(business) {
        this.business = business;
        this.settings = {
            columns: {
                id: {
                    title: 'ID',
                },
                patientAvsNumber: {
                    title: 'Patient AVS Number',
                },
                doctorId: {
                    title: 'Doctor ID',
                },
                data: {
                    title: 'Data',
                },
            },
            attr: {
                class: 'table table-bordered table-striped table-hover table-sm',
            },
        };
        this.data = [];
    }
    FilesTableComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.business.getMedicalFiles().subscribe(function (d) { return _this.data = d; });
    };
    FilesTableComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-files-table',
            template: "\n    <ng2-smart-table [settings]=\"settings\" [source]=\"data\"></ng2-smart-table>\n  ",
        }),
        __metadata("design:paramtypes", [_core_data_business_service__WEBPACK_IMPORTED_MODULE_1__["BusinessService"]])
    ], FilesTableComponent);
    return FilesTableComponent;
}());



/***/ }),

/***/ "./src/app/pages/hospitals-page/hospitals-page.component.html":
/*!********************************************************************!*\
  !*** ./src/app/pages/hospitals-page/hospitals-page.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n  <nb-card>\n    <nb-card-header>\n      Hospitals\n    </nb-card-header>\n    <nb-card-body>\n      <ngx-hospitals-table></ngx-hospitals-table>\n    </nb-card-body>\n  </nb-card>\n</div>"

/***/ }),

/***/ "./src/app/pages/hospitals-page/hospitals-page.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/pages/hospitals-page/hospitals-page.component.ts ***!
  \******************************************************************/
/*! exports provided: HospitalsPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HospitalsPageComponent", function() { return HospitalsPageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var HospitalsPageComponent = /** @class */ (function () {
    function HospitalsPageComponent() {
    }
    HospitalsPageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-hospitals-page',
            template: __webpack_require__(/*! ./hospitals-page.component.html */ "./src/app/pages/hospitals-page/hospitals-page.component.html"),
        })
    ], HospitalsPageComponent);
    return HospitalsPageComponent;
}());



/***/ }),

/***/ "./src/app/pages/hospitals-page/hospitals-page.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/hospitals-page/hospitals-page.module.ts ***!
  \***************************************************************/
/*! exports provided: HospitalsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HospitalsPageModule", function() { return HospitalsPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../@theme/theme.module */ "./src/app/@theme/theme.module.ts");
/* harmony import */ var _hospitals_page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./hospitals-page.component */ "./src/app/pages/hospitals-page/hospitals-page.component.ts");
/* harmony import */ var _table_table_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./table/table.component */ "./src/app/pages/hospitals-page/table/table.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var HospitalsPageModule = /** @class */ (function () {
    function HospitalsPageModule() {
    }
    HospitalsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__["ThemeModule"],
            ],
            declarations: [
                _hospitals_page_component__WEBPACK_IMPORTED_MODULE_2__["HospitalsPageComponent"],
                _table_table_component__WEBPACK_IMPORTED_MODULE_3__["HospitalsTableComponent"],
            ],
        })
    ], HospitalsPageModule);
    return HospitalsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/hospitals-page/table/table.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/hospitals-page/table/table.component.ts ***!
  \***************************************************************/
/*! exports provided: HospitalsTableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HospitalsTableComponent", function() { return HospitalsTableComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core_data_business_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../@core/data/business.service */ "./src/app/@core/data/business.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var HospitalsTableComponent = /** @class */ (function () {
    function HospitalsTableComponent(business) {
        this.business = business;
        this.settings = {
            columns: {
                id: {
                    title: 'ID',
                },
                name: {
                    title: 'Name',
                },
                city: {
                    title: 'City',
                },
            },
            attr: {
                class: 'table table-bordered table-striped table-hover table-sm',
            },
        };
        this.data = [];
    }
    HospitalsTableComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.business.getHospitals().subscribe(function (h) { return _this.data = h; });
    };
    HospitalsTableComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-hospitals-table',
            template: "\n    <ng2-smart-table [settings]=\"settings\" [source]=\"data\"></ng2-smart-table>\n  ",
        }),
        __metadata("design:paramtypes", [_core_data_business_service__WEBPACK_IMPORTED_MODULE_1__["BusinessService"]])
    ], HospitalsTableComponent);
    return HospitalsTableComponent;
}());



/***/ }),

/***/ "./src/app/pages/pages-menu.ts":
/*!*************************************!*\
  !*** ./src/app/pages/pages-menu.ts ***!
  \*************************************/
/*! exports provided: MENU_ITEMS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MENU_ITEMS", function() { return MENU_ITEMS; });
var MENU_ITEMS = [
    {
        title: 'Dashboard',
        icon: 'nb-tables',
        link: '/pages/dashboard',
        home: true,
    },
    {
        title: 'BUSINESS',
        group: true,
    },
    {
        title: 'Hospitals',
        icon: 'nb-home',
        link: '/pages/hospitals',
    },
    {
        title: 'Departments',
        icon: 'nb-list',
        link: '/pages/departments',
    },
    {
        title: 'Doctors',
        icon: 'nb-person',
        link: '/pages/doctors',
    },
    {
        title: 'Patients',
        icon: 'nb-person',
        link: '/pages/patients',
    },
    {
        title: 'Files',
        icon: 'nb-compose',
        link: '/pages/files',
    },
    {
        title: 'FEATURES',
        group: true,
    },
    {
        title: 'Auth',
        icon: 'nb-locked',
        children: [
            {
                title: 'Login',
                link: '/auth/login',
            },
            {
                title: 'Register',
                link: '/auth/register',
            },
            {
                title: 'Request Password',
                link: '/auth/request-password',
            },
            {
                title: 'Reset Password',
                link: '/auth/reset-password',
            },
        ],
    },
];


/***/ }),

/***/ "./src/app/pages/pages-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/pages-routing.module.ts ***!
  \***********************************************/
/*! exports provided: PagesRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesRoutingModule", function() { return PagesRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _pages_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages.component */ "./src/app/pages/pages.component.ts");
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dashboard/dashboard.component */ "./src/app/pages/dashboard/dashboard.component.ts");
/* harmony import */ var _hospitals_page_hospitals_page_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./hospitals-page/hospitals-page.component */ "./src/app/pages/hospitals-page/hospitals-page.component.ts");
/* harmony import */ var _departments_page_departments_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./departments-page/departments-page.component */ "./src/app/pages/departments-page/departments-page.component.ts");
/* harmony import */ var _doctors_page_doctors_page_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./doctors-page/doctors-page.component */ "./src/app/pages/doctors-page/doctors-page.component.ts");
/* harmony import */ var _patients_page_patients_page_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./patients-page/patients-page.component */ "./src/app/pages/patients-page/patients-page.component.ts");
/* harmony import */ var _files_page_files_page_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./files-page/files-page.component */ "./src/app/pages/files-page/files-page.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var routes = [{
        path: '',
        component: _pages_component__WEBPACK_IMPORTED_MODULE_2__["PagesComponent"],
        children: [
            {
                path: 'dashboard',
                component: _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__["DashboardComponent"],
            },
            {
                path: 'hospitals',
                component: _hospitals_page_hospitals_page_component__WEBPACK_IMPORTED_MODULE_4__["HospitalsPageComponent"],
            },
            {
                path: 'departments',
                component: _departments_page_departments_page_component__WEBPACK_IMPORTED_MODULE_5__["DepartmentsPageComponent"],
            },
            {
                path: 'doctors',
                component: _doctors_page_doctors_page_component__WEBPACK_IMPORTED_MODULE_6__["DoctorsPageComponent"],
            },
            {
                path: 'patients',
                component: _patients_page_patients_page_component__WEBPACK_IMPORTED_MODULE_7__["PatientsPageComponent"],
            },
            {
                path: 'files',
                component: _files_page_files_page_component__WEBPACK_IMPORTED_MODULE_8__["FilesPageComponent"],
            },
            {
                path: '',
                redirectTo: 'dashboard',
                pathMatch: 'full',
            },
        ],
    }];
var PagesRoutingModule = /** @class */ (function () {
    function PagesRoutingModule() {
    }
    PagesRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]],
        })
    ], PagesRoutingModule);
    return PagesRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/pages.component.ts":
/*!******************************************!*\
  !*** ./src/app/pages/pages.component.ts ***!
  \******************************************/
/*! exports provided: PagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesComponent", function() { return PagesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _pages_menu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages-menu */ "./src/app/pages/pages-menu.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var PagesComponent = /** @class */ (function () {
    function PagesComponent() {
        this.menu = _pages_menu__WEBPACK_IMPORTED_MODULE_1__["MENU_ITEMS"];
    }
    PagesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-pages',
            template: "\n    <ngx-sample-layout>\n      <nb-menu [items]=\"menu\"></nb-menu>\n      <router-outlet></router-outlet>\n    </ngx-sample-layout>\n  ",
        })
    ], PagesComponent);
    return PagesComponent;
}());



/***/ }),

/***/ "./src/app/pages/pages.module.ts":
/*!***************************************!*\
  !*** ./src/app/pages/pages.module.ts ***!
  \***************************************/
/*! exports provided: PagesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesModule", function() { return PagesModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _pages_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages.component */ "./src/app/pages/pages.component.ts");
/* harmony import */ var _dashboard_dashboard_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dashboard/dashboard.module */ "./src/app/pages/dashboard/dashboard.module.ts");
/* harmony import */ var _pages_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages-routing.module */ "./src/app/pages/pages-routing.module.ts");
/* harmony import */ var _theme_theme_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../@theme/theme.module */ "./src/app/@theme/theme.module.ts");
/* harmony import */ var _departments_page_departments_page_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./departments-page/departments-page.module */ "./src/app/pages/departments-page/departments-page.module.ts");
/* harmony import */ var _doctors_page_doctors_page_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./doctors-page/doctors-page.module */ "./src/app/pages/doctors-page/doctors-page.module.ts");
/* harmony import */ var _files_page_files_page_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./files-page/files-page.module */ "./src/app/pages/files-page/files-page.module.ts");
/* harmony import */ var _hospitals_page_hospitals_page_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./hospitals-page/hospitals-page.module */ "./src/app/pages/hospitals-page/hospitals-page.module.ts");
/* harmony import */ var _patients_page_patients_page_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./patients-page/patients-page.module */ "./src/app/pages/patients-page/patients-page.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var PAGES_COMPONENTS = [
    _pages_component__WEBPACK_IMPORTED_MODULE_1__["PagesComponent"],
];
var PagesModule = /** @class */ (function () {
    function PagesModule() {
    }
    PagesModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _pages_routing_module__WEBPACK_IMPORTED_MODULE_3__["PagesRoutingModule"],
                _theme_theme_module__WEBPACK_IMPORTED_MODULE_4__["ThemeModule"],
                _dashboard_dashboard_module__WEBPACK_IMPORTED_MODULE_2__["DashboardModule"],
                _departments_page_departments_page_module__WEBPACK_IMPORTED_MODULE_5__["DepartmentsPageModule"],
                _doctors_page_doctors_page_module__WEBPACK_IMPORTED_MODULE_6__["DoctorsPageModule"],
                _files_page_files_page_module__WEBPACK_IMPORTED_MODULE_7__["FilesPageModule"],
                _hospitals_page_hospitals_page_module__WEBPACK_IMPORTED_MODULE_8__["HospitalsPageModule"],
                _patients_page_patients_page_module__WEBPACK_IMPORTED_MODULE_9__["PatientsPageModule"],
            ],
            declarations: PAGES_COMPONENTS.slice(),
        })
    ], PagesModule);
    return PagesModule;
}());



/***/ }),

/***/ "./src/app/pages/patients-page/patients-page.component.html":
/*!******************************************************************!*\
  !*** ./src/app/pages/patients-page/patients-page.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n  <nb-card>\n    <nb-card-header>\n      Patients\n    </nb-card-header>\n    <nb-card-body>\n      <ngx-patients-table></ngx-patients-table>\n    </nb-card-body>\n  </nb-card>\n</div>\n  "

/***/ }),

/***/ "./src/app/pages/patients-page/patients-page.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/pages/patients-page/patients-page.component.ts ***!
  \****************************************************************/
/*! exports provided: PatientsPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientsPageComponent", function() { return PatientsPageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var PatientsPageComponent = /** @class */ (function () {
    function PatientsPageComponent() {
    }
    PatientsPageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-patients-page',
            template: __webpack_require__(/*! ./patients-page.component.html */ "./src/app/pages/patients-page/patients-page.component.html"),
        })
    ], PatientsPageComponent);
    return PatientsPageComponent;
}());



/***/ }),

/***/ "./src/app/pages/patients-page/patients-page.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/patients-page/patients-page.module.ts ***!
  \*************************************************************/
/*! exports provided: PatientsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientsPageModule", function() { return PatientsPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../@theme/theme.module */ "./src/app/@theme/theme.module.ts");
/* harmony import */ var _patients_page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./patients-page.component */ "./src/app/pages/patients-page/patients-page.component.ts");
/* harmony import */ var _table_table_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./table/table.component */ "./src/app/pages/patients-page/table/table.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var PatientsPageModule = /** @class */ (function () {
    function PatientsPageModule() {
    }
    PatientsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__["ThemeModule"],
            ],
            declarations: [
                _patients_page_component__WEBPACK_IMPORTED_MODULE_2__["PatientsPageComponent"],
                _table_table_component__WEBPACK_IMPORTED_MODULE_3__["PatientsTableComponent"],
            ],
        })
    ], PatientsPageModule);
    return PatientsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/patients-page/table/table.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/patients-page/table/table.component.ts ***!
  \**************************************************************/
/*! exports provided: PatientsTableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientsTableComponent", function() { return PatientsTableComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core_data_business_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../@core/data/business.service */ "./src/app/@core/data/business.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var PatientsTableComponent = /** @class */ (function () {
    function PatientsTableComponent(business) {
        this.business = business;
        this.settings = {
            columns: {
                id: {
                    title: 'ID',
                },
                firstName: {
                    title: 'First name',
                },
                lastName: {
                    title: 'Last name',
                },
                birthDate: {
                    title: 'Birthdate',
                    valuePrepareFunction: function (b) {
                        return b.substring(0, 10);
                    },
                },
                avsNumber: {
                    title: 'AVS Number',
                },
            },
            attr: {
                class: 'table table-bordered table-striped table-hover table-sm',
            },
        };
        this.data = [];
    }
    PatientsTableComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.business.getPatients().subscribe(function (p) { return _this.data = p; });
    };
    PatientsTableComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-patients-table',
            template: "\n    <ng2-smart-table [settings]=\"settings\" [source]=\"data\"></ng2-smart-table>\n  ",
        }),
        __metadata("design:paramtypes", [_core_data_business_service__WEBPACK_IMPORTED_MODULE_1__["BusinessService"]])
    ], PatientsTableComponent);
    return PatientsTableComponent;
}());



/***/ })

}]);
//# sourceMappingURL=app-pages-pages-module.js.map